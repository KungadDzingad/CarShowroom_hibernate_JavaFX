package com.wojtek.sample;

public class WrongRatingException extends Exception {
    public WrongRatingException(){
        super();
    }
}
